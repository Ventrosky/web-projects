﻿var XLSX = require('../');
var testCommon = require('./Common.js');

var file = 'issue.xlsx';

describe(file, function () {
	testCommon(file);
});